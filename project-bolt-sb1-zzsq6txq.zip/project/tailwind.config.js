/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'poppins': ['Poppins', 'sans-serif'],
      },
      colors: {
        'red': {
          600: '#DA1C36',
          700: '#c91829',
        },
        'yellow': {
          400: '#FFD700',
        },
        'blue': {
          50: '#F5FBFF',
        }
      },
      boxShadow: {
        'md': '0 4px 12px rgba(0,0,0,0.06)',
        'lg': '0 8px 24px rgba(0,0,0,0.08)',
        'xl': '0 12px 32px rgba(0,0,0,0.12)',
      },
    },
  },
  plugins: [],
};