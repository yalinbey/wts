import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Star, Play, Menu, X } from 'lucide-react';

function App() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const services = [
    {
      icon: '🧠',
      title: 'Web Tasarım',
      description: 'Modern, işlevsel, mobil uyumlu, yenilikçi web tasarım hizmetleri sunuyoruz.',
      position: 'left'
    },
    {
      icon: '⚙️',
      title: 'SEO Optimizasyonu',
      description: 'Temel ve modern SEO kurallara uygun web sitesi geliştirme hizmetleri.',
      position: 'left'
    },
    {
      icon: '📊',
      title: 'Logo & Kurumsal Kimlik',
      description: 'Hatırlanması kolay, etkileyici logo ve kurumsal kimlik tasarım hizmetleri.',
      position: 'left'
    },
    {
      icon: '💻',
      title: 'Yazılım Geliştirme',
      description: 'PHP, JavaScript, .NET gibi modern dillerle yazılım geliştirme hizmetleri.',
      position: 'right'
    },
    {
      icon: '📱',
      title: 'Reklam Yönetimi',
      description: 'Facebook, Instagram, Twitter kampanya yönetimi ve optimizasyon hizmetleri.',
      position: 'right'
    },
    {
      icon: '🎯',
      title: 'Web Danışmanlık',
      description: 'Tüm bilişim ihtiyaçlarınıza profesyonel çözüm üretim hizmetleri.',
      position: 'right'
    }
  ];

  const workSteps = [
    {
      icon: '📋',
      title: 'Planlama',
      description: 'İstek analizi yaparak hedefe göre hareket ediyoruz.'
    },
    {
      icon: '🎨',
      title: 'Görsel Tasarım',
      description: 'Konsept belirleme ve grafik tasarımı yapıyoruz.'
    },
    {
      icon: '⚡',
      title: 'Kodlama',
      description: 'Kod geliştirme ve sistem entegrasyonu yapıyoruz.'
    },
    {
      icon: '🔍',
      title: 'SEO',
      description: 'Site içi ve dışı SEO optimizasyonu yapıyoruz.'
    },
    {
      icon: '🚀',
      title: 'Yayınlama',
      description: 'Onay sonrası yayın alma işlemini gerçekleştiriyoruz.'
    }
  ];

  const workProcess = [
    {
      icon: '📊',
      title: 'Planlama',
      description: 'Proje detaylarınızı analiz ederek en uygun çözümü planlıyoruz.'
    },
    {
      icon: '🎨',
      title: 'Görsel Tasarım',
      description: 'Yaratıcı ve etkili tasarımlarla markanızı öne çıkarıyoruz.'
    },
    {
      icon: '⚡',
      title: 'Kodlama',
      description: 'Modern teknolojilerle hızlı ve güvenli kodlama yapıyoruz.'
    },
    {
      icon: '🚀',
      title: 'Son Optimizasyon',
      description: 'Testlerden geçen projenizi canlı ortama alıyoruz.'
    }
  ];

  const projects = [
    'DryService',
    'K3 Çiçek Evi',
    'Arkom Teknik',
    'Grupas Gelişim',
    'Çekay Danışmanlık',
    'Hayat Tour'
  ];

  const blogPosts = [
    {
      title: 'Etkileyici Web Tasarım İpuçları',
      date: '15 Mart 2024',
      tag: 'Teknoloji',
      image: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Web Tasarım Stratejisi Nasıl Geliştirilir?',
      date: '12 Mart 2024',
      tag: 'Strateji',
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      title: 'Lighthouse Performans Optimizasyon Etmek',
      date: '10 Mart 2024',
      tag: 'Performans',
      image: 'https://images.pexels.com/photos/39284/macbook-apple-imac-computer-39284.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  const partners = [
    'Google', 'Yandex', 'Yahoo', 'Bing', 'Facebook', 'Twitter', 'YouTube', 'Symantec', 'GoDaddy', 'Microsoft', 'Adobe', 'Apple'
  ];

  const faqs = [
    {
      question: 'Web Tasarım Nedir?',
      answer: 'Web tasarım, web sitelerinin görsel ve işlevsel tasarımını içeren kapsamlı bir süreçtir. Bu süreç, kullanıcı deneyimi, görsel tasarım, içerik yönetimi ve teknik implementasyonu içerir.'
    },
    {
      question: 'Fiyatlar Nasıl Belirleniyor?',
      answer: 'Fiyatlarımız projenin kapsamı, karmaşıklığı, süre ve özel gereksinimlerine göre belirlenir. Ücretsiz konsültasyon sonrası size özel teklif hazırlıyoruz.'
    },
    {
      question: 'Örnek Projeler Görebilir miyim?',
      answer: 'Elbette! Portföyümüzde birçok farklı sektörden başarılı proje örneklerimiz bulunmaktadır. Detaylı incelemek için bizimle iletişime geçebilirsiniz.'
    },
    {
      question: 'Danışmanlık Hizmeti Nedir?',
      answer: 'Web danışmanlık hizmetimiz, dijital stratejinizi optimize etmek, doğru teknoloji seçimini yapmak ve online varlığınızı güçlendirmek için sunduğumuz kapsamlı danışmanlık hizmetidir.'
    },
    {
      question: 'Kurumsal Site Nedir?',
      answer: 'Kurumsal web sitesi, şirketinizin dijital kimliğini yansıtan, profesyonel görünümlü ve işlevsel web sitesidir. Marka imajınızı güçlendiren önemli bir araçtır.'
    },
    {
      question: 'Neden Bizi Tercih Etmelisiniz?',
      answer: 'Deneyimli ekibimiz, kaliteli hizmet anlayışımız, zamanında teslimat garantimiz ve sürekli destek hizmetimiz ile fark yaratıyoruz.'
    }
  ];

  const testimonials = [
    {
      name: 'Chunky Animal',
      comment: 'Harika bir ekip! Projemizi zamanında ve beklediğimizden daha iyi teslim ettiler.',
      platform: 'Google'
    },
    {
      name: 'Birlik DTM',
      comment: 'Profesyonel yaklaşım ve kaliteli hizmet için teşekkürler.',
      platform: 'Facebook'
    },
    {
      name: 'Nazlı Türkmen',
      comment: 'Web sitemiz çok beğeniliyor, SEO çalışmaları da çok başarılı.',
      platform: 'Google'
    },
    {
      name: 'Furkan Yalçın',
      comment: 'Danışmanlık hizmetleri sayesinde satışlarımız arttı.',
      platform: 'LinkedIn'
    },
    {
      name: 'Bengi Şan',
      comment: 'Logo tasarımımız çok başarılı oldu, çok memnunuz.',
      platform: 'Instagram'
    },
    {
      name: 'TÜRDEF',
      comment: 'Kurumsal kimlik çalışması beklentilerimizi aştı.',
      platform: 'Google'
    }
  ];

  return (
    <div className="font-poppins">
      {/* Header */}
      <header className="bg-black text-white py-3 fixed w-full top-0 z-50">
        <div className="container mx-auto px-4 flex justify-between items-center">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="relative">
              {/* Logo background */}
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center relative overflow-hidden">
                {/* Geometric shapes */}
                <div className="absolute inset-0">
                  <div className="absolute top-1 left-1 w-4 h-4 bg-blue-400 rounded-sm transform rotate-12"></div>
                  <div className="absolute bottom-1 right-1 w-3 h-3 bg-yellow-400 rounded-sm transform -rotate-12"></div>
                  <div className="absolute top-2 right-2 w-2 h-2 bg-green-400 rounded-full"></div>
                </div>
                {/* Main logo text */}
                <span className="text-white font-bold text-lg relative z-10">W</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-base leading-tight">WebTasarım</span>
              <span className="font-bold text-base leading-tight">Sistemleri</span>
            </div>
            {/* Registered trademark */}
            <span className="text-xs text-gray-400 mt-[-10px]">®</span>
          </div>

          {/* Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <div className="relative group">
              <a href="#" className="text-white hover:text-red-500 transition-colors flex items-center space-x-1">
                <span>akademi</span>
                <ChevronDown className="w-4 h-4" />
              </a>
            </div>
            <div className="relative group">
              <a href="#" className="text-white hover:text-red-500 transition-colors flex items-center space-x-1">
                <span>hizmetler</span>
                <ChevronDown className="w-4 h-4" />
              </a>
            </div>
            <a href="#" className="text-white hover:text-red-500 transition-colors">projeler</a>
            <a href="#" className="text-white hover:text-red-500 transition-colors">blog</a>
            <div className="relative group">
              <a href="#" className="text-white hover:text-red-500 transition-colors flex items-center space-x-1">
                <span>kurumsal</span>
                <ChevronDown className="w-4 h-4" />
              </a>
            </div>
            <a href="#" className="text-white hover:text-red-500 transition-colors">iletişim</a>
          </nav>

          {/* Right side button */}
          <div className="hidden lg:flex items-center">
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
              <div className="w-5 h-5 bg-white bg-opacity-20 rounded flex items-center justify-center">
                <span className="text-xs">📋</span>
              </div>
              <span>Teklif Al</span>
            </button>
          </div>

          {/* Mobile menu button */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-black border-t border-gray-800">
            <nav className="flex flex-col space-y-4 p-4">
              <a href="#" className="text-white hover:text-red-500 transition-colors">akademi</a>
              <a href="#" className="text-white hover:text-red-500 transition-colors">hizmetler</a>
              <a href="#" className="text-white hover:text-red-500 transition-colors">projeler</a>
              <a href="#" className="text-white hover:text-red-500 transition-colors">blog</a>
              <a href="#" className="text-white hover:text-red-500 transition-colors">kurumsal</a>
              <a href="#" className="text-white hover:text-red-500 transition-colors">iletişim</a>
              <button className="bg-blue-500 text-white px-4 py-2 rounded-lg font-medium mt-4 w-full">
                Teklif Al
              </button>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="bg-black text-white min-h-screen flex items-center justify-center pt-20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <div className="inline-block bg-gray-800 px-6 py-3 rounded-full mb-6">
                <span className="text-sm text-gray-300">Türkiye'nin En Güçlü Web Tasarım Ajansı</span>
              </div>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="text-blue-400">Etkileyici</span> <span className="text-white">Web Tasarım</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Türkiye'nin Güçlü Web Tasarım Ajansı ile
              <br />
              Dijital Dünyanın En İyi Sitelerini Keşfet
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-semibold transition-colors">
                Hemen Başla
              </button>
              <button className="border-2 border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white px-8 py-3 rounded-full font-semibold transition-colors">
                Projelerimizi İncele
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Neler Yapıyoruz Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-block bg-red-600 p-3 rounded-full mb-4">
              <span className="text-white text-2xl">⚡</span>
            </div>
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Neler Yapıyoruz ?
            </h2>
          </div>
          
          <div className="relative max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
              {/* Left Services */}
              <div className="space-y-8">
                {services.filter(s => s.position === 'left').map((service, index) => (
                  <div key={index} className="group cursor-pointer">
                    <div className="flex items-center space-x-4 p-6 rounded-xl hover:shadow-lg transition-all duration-300">
                      <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                        {service.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-black group-hover:text-red-600 transition-colors">
                          {service.title}
                        </h3>
                        <p className="text-gray-500 text-sm mt-2">{service.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Center Phone */}
              <div className="flex justify-center">
                <div className="relative">
                  <div className="w-80 h-96 bg-black rounded-3xl p-2 shadow-2xl">
                    <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center relative overflow-hidden">
                      {/* Phone content with colorful icons */}
                      <div className="absolute inset-0 p-6">
                        <div className="grid grid-cols-4 gap-3 h-full">
                          {/* App icons */}
                          <div className="w-12 h-12 bg-red-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-blue-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-green-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-yellow-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-purple-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-pink-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-indigo-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-orange-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-teal-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-cyan-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-lime-500 rounded-xl"></div>
                          <div className="w-12 h-12 bg-amber-500 rounded-xl"></div>
                        </div>
                      </div>
                      <div className="text-white text-center z-10">
                        <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-2xl">📱</span>
                        </div>
                        <h3 className="text-xl font-semibold">Mobil Uyumlu</h3>
                        <p className="text-sm opacity-80">Responsive Tasarım</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Services */}
              <div className="space-y-8">
                {services.filter(s => s.position === 'right').map((service, index) => (
                  <div key={index} className="group cursor-pointer">
                    <div className="flex items-center space-x-4 p-6 rounded-xl hover:shadow-lg transition-all duration-300">
                      <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                        {service.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-black group-hover:text-red-600 transition-colors">
                          {service.title}
                        </h3>
                        <p className="text-gray-500 text-sm mt-2">{service.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Nasıl Yapıyoruz Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Nasıl Yapıyoruz ?
            </h2>
            <div className="w-24 h-1 bg-red-600 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
            {workSteps.map((step, index) => (
              <div key={index} className="group text-center">
                <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl group-hover:text-red-600 transition-colors">
                    {step.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-black mb-4">{step.title}</h3>
                  <p className="text-gray-500 text-sm">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 bg-black text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">38.580.000 +</div>
              <div className="text-gray-300">Satır Yazılan Kod</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">240.000 +</div>
              <div className="text-gray-300">Test Veri Sayısı</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">740 +</div>
              <div className="text-gray-300">Teslim Proje Sayısı</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-yellow-400 mb-2">1.600 +</div>
              <div className="text-gray-300">Mutlu Müşteri</div>
            </div>
          </div>
        </div>
      </section>

      {/* Nasıl Çalışıyoruz - Process Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Nasıl Çalışıyoruz ?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {workProcess.map((item, index) => (
              <div key={index} className="text-center group">
                <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl group-hover:bg-red-100 transition-colors">
                  {item.icon}
                </div>
                <h3 className="text-xl font-semibold text-black mb-4">{item.title}</h3>
                <p className="text-gray-500">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Neler Yaptık Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <div className="inline-block bg-red-600 p-3 rounded-full mb-4">
              <span className="text-white text-2xl">📸</span>
            </div>
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Neler Yaptık ?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {projects.map((project, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="bg-white rounded-2xl p-8 shadow-md hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                  <div className="w-full h-64 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl mb-6 flex items-center justify-center">
                    <div className="text-white text-center">
                      <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-2xl">📱</span>
                      </div>
                      <h3 className="text-xl font-semibold">{project}</h3>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-semibold transition-colors">
              Tüm Projeleri İncele
            </button>
          </div>
        </div>
      </section>

      {/* Neler Yazdık Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Neler Yazdık ?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                  <div className="h-48 bg-cover bg-center" style={{ backgroundImage: `url(${post.image})` }}></div>
                  <div className="p-6">
                    <span className="inline-block bg-yellow-400 text-black px-3 py-1 rounded-full text-sm font-medium mb-3">
                      {post.tag}
                    </span>
                    <h3 className="text-lg font-semibold text-black mb-2 group-hover:text-red-600 transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-500 text-sm">{post.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Kimlerle Çalışıyoruz Section */}
      <section className="py-24 bg-yellow-400 transform -skew-y-2">
        <div className="transform skew-y-2">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-black mb-4">
                <span className="text-red-600">#</span> Kimlerle Çalışıyoruz ?
              </h2>
              <div className="w-24 h-1 bg-black mx-auto"></div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8">
              {partners.map((partner, index) => (
                <div key={index} className="text-center group">
                  <div className="bg-white bg-opacity-20 rounded-xl p-6 hover:bg-opacity-40 transition-all duration-300 group-hover:scale-110">
                    <div className="text-2xl font-bold text-black">{partner}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Neler Soruluyor Section */}
      <section className="py-24 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Neler Soruluyor ?
            </h2>
          </div>

          <div className="max-w-4xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-xl shadow-md overflow-hidden">
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <span className="text-red-600 text-xl">❓</span>
                    <span className="text-lg font-semibold text-black">{faq.question}</span>
                  </div>
                  {openFaq === index ? <ChevronUp className="text-red-600" /> : <ChevronDown className="text-red-600" />}
                </button>
                {openFaq === index && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Neler Söylediler Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-black mb-4">
              <span className="text-red-600">#</span> Neler Söylediler ?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 group-hover:-translate-y-2 group-hover:bg-gray-50">
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-red-600 text-red-600" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4">"{testimonial.comment}"</p>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-black">{testimonial.name}</span>
                    <span className="text-sm text-gray-500">{testimonial.platform}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full font-semibold transition-colors">
              Tüm Yorumları Oku
            </button>
          </div>
        </div>
      </section>

      {/* Biz Kimiz Section */}
      <section className="py-24 bg-blue-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="w-full h-64 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center">
                  <div className="text-white text-center">
                    <Play className="w-16 h-16 mx-auto mb-4" />
                    <span className="text-lg font-semibold">Tanıtım Videosu</span>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h2 className="text-4xl font-bold text-black mb-6">Biz Kimiz?</h2>
              <p className="text-gray-600 mb-6">
                Türkiye'nin ödüllü web tasarım ajansı olarak, doğru strateji, yüksek kalite ve özgün tasarım 
                anlayışıyla hizmet veriyoruz. Yazılım geliştirme, web tasarım, sosyal medya yönetimi, 
                danışmanlık ve SEO alanlarında uzman kadromuzla müşterilerimize en iyi hizmeti sunuyoruz.
              </p>
              <p className="text-gray-600 mb-8">
                Modern teknolojileri kullanarak, müşterilerimizin dijital hedeflerine ulaşmasında 
                güvenilir bir iş ortağı olarak yanlarındayız. Kaliteli hizmet, zamanında teslimat ve 
                sürekli destek ilkelerimizle sektörde öncü olmaya devam ediyoruz.
              </p>
              <p className="text-sm text-gray-500">
                Web Tasarım Sistemleri bir Narcsoft Bilişim Tic. Ltd. Şti. Markasıdır.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">W</span>
                </div>
                <span className="font-bold text-lg">Web Tasarım Sistemleri</span>
              </div>
              <p className="text-gray-400">
                Türkiye'nin güçlü web tasarım ajansı ile dijital dünyanın en iyi sitelerini keşfedin.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Hizmetler</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Web Tasarım</li>
                <li>SEO Optimizasyonu</li>
                <li>Logo Tasarım</li>
                <li>Yazılım Geliştirme</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Şirket</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Hakkımızda</li>
                <li>Projeler</li>
                <li>Blog</li>
                <li>İletişim</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">İletişim</h4>
              <ul className="space-y-2 text-gray-400">
                <li>info@webtasarimsistemleri.com</li>
                <li>+90 xxx xxx xx xx</li>
                <li>İstanbul, Türkiye</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Web Tasarım Sistemleri. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;